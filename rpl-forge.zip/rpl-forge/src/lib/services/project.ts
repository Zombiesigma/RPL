import type { Commit, NewProjectInput, Project, ProjectFile, Repository, Version } from "../types";
import { slugify, uid } from "../utils";
import { repositoryService } from "./repository";
import { deploymentService } from "./deployment";
import { DEMO_USERS } from "./auth";

/**
 * ProjectService — persistence + project lifecycle.
 * Prototype: LocalProjectService (localStorage). Production: Firestore.
 */
export interface IProjectService {
  list(): Project[];
  listByOwner(ownerId: string): Project[];
  get(id: string): Project | null;
  create(input: NewProjectInput, ownerId: string): Promise<Project>;
  update(id: string, patch: Partial<Project>): Project | null;
  remove(id: string): void;
  save(project: Project): void;
  addCommit(id: string, commit: Commit): Project | null;
  addVersion(id: string, version: Version): Project | null;
  listPublic(): Project[];
}

const KEY = "rplforge.projects.v1";

const REPO_NAME = "Repository created via upload";

function mkFile(path: string, content: string): ProjectFile {
  return { path, content, size: content.length, updatedAt: new Date().toISOString() };
}

export class LocalProjectService implements IProjectService {
  private cache: Project[] | null = null;

  private load(): Project[] {
    if (this.cache) return this.cache;
    if (typeof window === "undefined") return [];
    try {
      const raw = localStorage.getItem(KEY);
      this.cache = raw ? (JSON.parse(raw) as Project[]) : seedProjects();
      if (!raw) this.persist();
    } catch {
      this.cache = seedProjects();
    }
    return this.cache!;
  }

  private persist() {
    if (typeof window === "undefined" || !this.cache) return;
    try {
      localStorage.setItem(KEY, JSON.stringify(this.cache));
    } catch (e) {
      console.warn("RPL Forge: storage quota exceeded; project kept in memory only.", e);
    }
  }

  list() {
    return [...this.load()].sort(
      (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );
  }

  listByOwner(ownerId: string) {
    return this.list().filter((p) => p.ownerId === ownerId);
  }

  listPublic() {
    return this.list().filter((p) => p.visibility === "public");
  }

  get(id: string) {
    return this.load().find((p) => p.id === id) ?? null;
  }

  async create(input: NewProjectInput, ownerId: string): Promise<Project> {
    const now = new Date().toISOString();
    const id = uid("prj-");
    const repo = await repositoryService.createRepository(input.name, id);
    const deployment = await deploymentService.createDeployment({
      id,
      slug: slugify(input.name),
    } as Project);
    const files = input.files.map((f) => mkFile(f.path, f.content));
    const initialCommit: Commit = {
      id: uid("cmt-"),
      message: "Initial upload",
      author: ownerId,
      changedFiles: files.map((f) => f.path),
      createdAt: now,
    };
    const v1: Version = {
      id: uid("ver-"),
      label: "v1.0",
      message: "Initial upload",
      commitId: initialCommit.id,
      createdAt: now,
    };
    const project: Project = {
      id,
      name: input.name,
      slug: slugify(input.name),
      description: input.description,
      ownerId,
      category: input.category,
      technologies: input.technologies,
      visibility: input.visibility,
      status: "LIVE",
      repository: repo,
      deployment,
      files,
      commits: [initialCommit],
      versions: [v1],
      screenshots: [],
      createdAt: now,
      updatedAt: now,
    };
    this.load().unshift(project);
    this.persist();
    return project;
  }

  update(id: string, patch: Partial<Project>) {
    const projects = this.load();
    const idx = projects.findIndex((p) => p.id === id);
    if (idx === -1) return null;
    projects[idx] = { ...projects[idx], ...patch, updatedAt: new Date().toISOString() };
    this.persist();
    return projects[idx];
  }

  remove(id: string) {
    const projects = this.load();
    const idx = projects.findIndex((p) => p.id === id);
    if (idx !== -1) {
      projects.splice(idx, 1);
      this.persist();
    }
  }

  save(project: Project) {
    this.update(project.id, project);
  }

  addCommit(id: string, commit: Commit) {
    const p = this.get(id);
    if (!p) return null;
    return this.update(id, { commits: [commit, ...p.commits] });
  }

  addVersion(id: string, version: Version) {
    const p = this.get(id);
    if (!p) return null;
    return this.update(id, { versions: [version, ...p.versions] });
  }
}

/* ------------------------- seed data ------------------------- */

const DEMO_PAGE_TSX = `import React from "react";

export default function Page() {
  return (
    <main className="p-8">
      <h1 className="text-2xl font-bold">Smart Attendance</h1>
      <p>Scan the ESP32 QR reader to mark yourself present.</p>
    </main>
  );
}
`;

const DEMO_README = `# Smart Attendance

Sistem absensi cerdas berbasis QR + ESP32.

- Scan QR via ESP32 camera
- Records to Firebase Realtime DB
- Dashboard rekap kehadiran
`;

function seedProjects(): Project[] {
  const andi = DEMO_USERS[0];
  const budi = DEMO_USERS[1];
  const citra = DEMO_USERS[2];
  const now = Date.now();

  const mk = (
    owner: typeof andi,
    name: string,
    description: string,
    category: string,
    technologies: string[],
    status: Project["status"],
    daysAgo: number,
    versions: [string, string][]
  ): Project => {
    const created = new Date(now - daysAgo * 86400000).toISOString();
    const commits: Commit[] = versions.map(([, msg], i) => ({
      id: uid("cmt-"),
      message: msg,
      author: owner.id,
      changedFiles: ["src/app/page.tsx"],
      createdAt: new Date(now - (daysAgo - i * 2) * 86400000).toISOString(),
    }));
    return {
      id: uid("prj-"),
      name,
      slug: slugify(name),
      description,
      ownerId: owner.id,
      category,
      technologies,
      visibility: "public",
      status,
      repository: {
        id: uid("repo-"),
        name: repositoryService.repoNameFor(name),
        projectId: "",
        defaultBranch: "main",
        createdAt: created,
      },
      deployment: {
        id: uid("dpl-"),
        projectId: "",
        status: status === "LIVE" ? "READY" : status === "FAILED" ? "FAILED" : "BUILDING",
        url: deploymentService.urlFor(slugify(name)),
        logs: [],
        createdAt: created,
      },
      files: [
        mkFile("src/app/page.tsx", DEMO_PAGE_TSX),
        mkFile("package.json", `{\n  "name": "${slugify(name)}",\n  "version": "1.0.0",\n  "private": true\n}\n`),
        mkFile("README.md", DEMO_README),
      ],
      commits,
      versions: versions.map(([label, msg], i) => ({
        id: uid("ver-"),
        label,
        message: msg,
        commitId: commits[i].id,
        createdAt: commits[i].createdAt,
      })),
      screenshots: [],
      createdAt: created,
      updatedAt: commits[0].createdAt,
    };
  };

  return [
    mk(andi, "Smart Attendance", "Sistem absensi QR berbasis ESP32 dengan dashboard realtime. Dibuat untuk tugas RPL kelas 12.", "IoT", ["Next.js", "Firebase", "ESP32"], "LIVE", 14, [["v1.0", "Initial upload"], ["v1.1", "Updated homepage"], ["v1.2", "Added dashboard"]]),
    mk(andi, "Kantin Digital", "Aplikasi pemesanan makanan kantin sekolah dengan antrean virtual.", "Web Development", ["React", "Tailwind", "Supabase"], "LIVE", 9, [["v1.0", "Initial upload"], ["v1.1", "Menu CRUD"]]),
    mk(budi, "E-Wallet Saku", "Dompet digital sederhana untuk uang saku siswa dengan pencatatan pengeluaran.", "Mobile", ["Flutter", "Firebase"], "DEPLOYING", 5, [["v1.0", "Initial upload"], ["v1.1", "Fixed balance bug"], ["v1.2", "Added charts"]]),
    mk(citra, "Prediksi Nilai ML", "Model machine learning untuk memprediksi nilai ujian siswa dari kebiasaan belajar.", "Data Science", ["Python", "Scikit-learn", "Pandas"], "FAILED", 7, [["v1.0", "Initial upload"]]),
    mk(budi, "Retro Arcade Pong", "Game Pong klasik dengan leaderboard online.", "Game", ["Canvas", "TypeScript"], "LIVE", 21, [["v1.0", "Initial upload"], ["v1.1", "Leaderboard"], ["v1.2", "Sound FX"], ["v1.3", "Mobile controls"]]),
  ];
}

export const projectService: IProjectService = new LocalProjectService();
export { REPO_NAME };
export type { Repository };
