import type { Commit, Deployment, Project, ProjectFile, Repository, Version } from "../types";
import { uid } from "../utils";

/**
 * RepositoryService — abstraction over source control.
 * Prototype: MockRepositoryService (in-memory + persisted with the project).
 * Production: GitHub App / GitHub API implementing the same interface.
 */
export interface IRepositoryService {
  createRepository(projectName: string, projectId: string): Promise<Repository>;
  getFiles(repoId: string, project: Project): ProjectFile[];
  readFile(project: Project, path: string): string | null;
  writeFile(project: Project, path: string, content: string): ProjectFile[];
  createFile(project: Project, path: string, content?: string): ProjectFile[];
  deleteFile(project: Project, path: string): ProjectFile[];
  renameFile(project: Project, oldPath: string, newPath: string): ProjectFile[];
  createCommit(project: Project, message: string, author: string, changedFiles: string[]): Commit;
  listCommits(project: Project): Commit[];
  repoNameFor(projectName: string): string;
}

export class MockRepositoryService implements IRepositoryService {
  repoNameFor(projectName: string) {
    return `rplforge-${projectName.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "")}`;
  }

  async createRepository(projectName: string, projectId: string): Promise<Repository> {
    await new Promise((r) => setTimeout(r, 700));
    return {
      id: uid("repo-"),
      name: this.repoNameFor(projectName),
      projectId,
      defaultBranch: "main",
      createdAt: new Date().toISOString(),
    };
  }

  getFiles(_repoId: string, project: Project): ProjectFile[] {
    return project.files;
  }

  readFile(project: Project, path: string) {
    return project.files.find((f) => f.path === path)?.content ?? null;
  }

  writeFile(project: Project, path: string, content: string): ProjectFile[] {
    const now = new Date().toISOString();
    const exists = project.files.some((f) => f.path === path);
    if (exists) {
      return project.files.map((f) =>
        f.path === path ? { ...f, content, size: content.length, updatedAt: now } : f
      );
    }
    return [...project.files, { path, content, size: content.length, updatedAt: now }];
  }

  createFile(project: Project, path: string, content = ""): ProjectFile[] {
    if (project.files.some((f) => f.path === path)) {
      throw new Error(`File already exists: ${path}`);
    }
    return this.writeFile(project, path, content);
  }

  deleteFile(project: Project, path: string): ProjectFile[] {
    return project.files.filter((f) => f.path !== path && !f.path.startsWith(path + "/"));
  }

  renameFile(project: Project, oldPath: string, newPath: string): ProjectFile[] {
    const exists = project.files.some((f) => f.path === newPath);
    if (exists) throw new Error(`Target already exists: ${newPath}`);
    return project.files.map((f) => {
      if (f.path === oldPath) return { ...f, path: newPath, updatedAt: new Date().toISOString() };
      if (f.path.startsWith(oldPath + "/")) {
        return { ...f, path: newPath + f.path.slice(oldPath.length) };
      }
      return f;
    });
  }

  createCommit(project: Project, message: string, author: string, changedFiles: string[]): Commit {
    return {
      id: uid("cmt-"),
      message,
      author,
      changedFiles,
      createdAt: new Date().toISOString(),
    };
  }

  listCommits(project: Project): Commit[] {
    return [...project.commits].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }
}

export const repositoryService: IRepositoryService = new MockRepositoryService();

/** Helper: bump version label (v1.0 -> v1.1) */
export function nextVersion(versions: Version[]): Version["label"] {
  const latest = versions[0]?.label ?? "v0.0";
  const minor = parseInt(latest.split(".")[1] ?? "0", 10) + 1;
  const major = latest.split(".")[0];
  return `${major}.${minor}`;
}

export type { Deployment, Repository };
