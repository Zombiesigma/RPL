import type { Deployment, DeploymentLog, DeploymentStatus, Project } from "../types";
import { uid } from "../utils";

/**
 * DeploymentService — abstraction over hosting/deploys.
 * Prototype: MockDeploymentService (simulated pipeline, no code execution).
 * Production: Vercel API implementing the same interface.
 *
 * SECURITY: uploaded project code is NEVER executed. This only simulates
 * pipeline state transitions with timed logs.
 */
export interface IDeploymentService {
  createDeployment(project: Project, commitId?: string): Promise<Deployment>;
  getStatus(deployment: Deployment): DeploymentStatus;
  retryDeployment(project: Project, deployment: Deployment): Promise<Deployment>;
  urlFor(slug: string): string;
}

function log(line: string): DeploymentLog {
  return { ts: new Date().toISOString(), line };
}

export class MockDeploymentService implements IDeploymentService {
  urlFor(slug: string) {
    return `https://${slug}.rplforge.local`;
  }

  async createDeployment(project: Project, commitId?: string): Promise<Deployment> {
    const now = new Date().toISOString();
    return {
      id: uid("dpl-"),
      projectId: project.id,
      status: "QUEUED",
      url: this.urlFor(project.slug),
      commitId,
      logs: [log("Queued deployment…")],
      createdAt: now,
    };
  }

  getStatus(d: Deployment): DeploymentStatus {
    return d.status;
  }

  async retryDeployment(project: Project): Promise<Deployment> {
    return this.createDeployment(project);
  }
}

/** Run the simulated pipeline: QUEUED → BUILDING → DEPLOYING → READY, emitting logs. */
export async function runPipeline(
  project: Project,
  deployment: Deployment,
  onProgress: (status: DeploymentStatus, logs: DeploymentLog[]) => void,
  speed = 1
): Promise<Deployment> {
  const logs = [...deployment.logs];
  const push = (line: string) => logs.push(log(line));
  const wait = (ms: number) => new Promise((r) => setTimeout(r, ms / speed));

  const set = (status: DeploymentStatus) => onProgress(status, [...logs]);

  set("BUILDING");
  push("$ forge build");
  push("→ Installing dependencies…");
  await wait(900);
  push("✓ Dependencies installed (1,284 packages)");
  push("→ Compiling project…");
  await wait(1100);
  push(`✓ Compiled ${project.files.length} files successfully`);
  set("DEPLOYING");
  push("→ Uploading static assets…");
  await wait(800);
  push("✓ Assets uploaded");
  push("→ Assigning domain…");
  await wait(600);
  push(`✓ Domain ready: ${deployment.url}`);
  set("READY");
  push("✓ Deployment ready");
  const ready: Deployment = {
    ...deployment,
    status: "READY",
    logs,
    readyAt: new Date().toISOString(),
  };
  onProgress("READY", logs);
  return ready;
}

export const deploymentService: IDeploymentService = new MockDeploymentService();
