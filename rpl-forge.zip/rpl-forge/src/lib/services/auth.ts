import type { User } from "../types";

/**
 * AuthService — abstraction over authentication.
 * Prototype: MockAuthService (localStorage session).
 * Production: Firebase Auth implementing the same interface.
 */
export interface IAuthService {
  getCurrentUser(): User | null;
  login(username: string): Promise<User>;
  logout(): Promise<void>;
  listDemoUsers(): User[];
  onChange(cb: (u: User | null) => void): () => void;
}

const SESSION_KEY = "rplforge.session";

export const DEMO_USERS: User[] = [
  {
    id: "u-andi",
    username: "andi",
    name: "Andi",
    role: "RPL Student",
    skills: ["Web Development", "IoT", "React"],
    bio: "Builds connected things. Next.js + ESP32 enthusiast.",
    avatarColor: "#F97316",
  },
  {
    id: "u-budi",
    username: "budi",
    name: "Budi",
    role: "RPL Student",
    skills: ["Mobile", "Flutter", "Firebase"],
    bio: "Mobile-first. Ships fast.",
    avatarColor: "#0EA5E9",
  },
  {
    id: "u-citra",
    username: "citra",
    name: "Citra",
    role: "RPL Student",
    skills: ["Data Science", "Python", "UI/UX"],
    bio: "Data-driven products and clean interfaces.",
    avatarColor: "#8B5CF6",
  },
];

export class MockAuthService implements IAuthService {
  private listeners = new Set<(u: User | null) => void>();

  getCurrentUser(): User | null {
    if (typeof window === "undefined") return null;
    try {
      const id = localStorage.getItem(SESSION_KEY);
      if (!id) return null;
      return DEMO_USERS.find((u) => u.id === id) ?? null;
    } catch {
      return null;
    }
  }

  async login(username: string): Promise<User> {
    const user = DEMO_USERS.find(
      (u) => u.username.toLowerCase() === username.toLowerCase()
    );
    if (!user) throw new Error("User not found. Try: andi, budi, or citra");
    await new Promise((r) => setTimeout(r, 600)); // simulate auth latency
    localStorage.setItem(SESSION_KEY, user.id);
    this.listeners.forEach((cb) => cb(user));
    return user;
  }

  async logout(): Promise<void> {
    localStorage.removeItem(SESSION_KEY);
    this.listeners.forEach((cb) => cb(null));
  }

  listDemoUsers() {
    return DEMO_USERS;
  }

  onChange(cb: (u: User | null) => void): () => void {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }
}

export const authService: IAuthService = new MockAuthService();
