import type { ProjectFile } from "../types";

/**
 * FileService — file tree helpers and folder upload.
 * UI uses this for the workspace file explorer and upload previews.
 */
export type TreeNode = {
  name: string;
  path: string;
  type: "file" | "dir";
  children?: TreeNode[];
};

export function buildTree(files: ProjectFile[]): TreeNode[] {
  const root: TreeNode = { name: "", path: "", type: "dir", children: [] };
  for (const f of [...files].sort((a, b) => a.path.localeCompare(b.path))) {
    const parts = f.path.split("/").filter(Boolean);
    let cur = root;
    parts.forEach((part, i) => {
      const isLeaf = i === parts.length - 1;
      const path = parts.slice(0, i + 1).join("/");
      let next = cur.children!.find((c) => c.name === part && c.type === (isLeaf ? "file" : "dir"));
      if (!next) {
        next = { name: part, path, type: isLeaf ? "file" : "dir", children: isLeaf ? undefined : [] };
        cur.children!.push(next);
      }
      cur = next;
    });
  }
  // dirs first, then files, alphabetical
  const sortRec = (n: TreeNode) => {
    n.children?.sort((a, b) =>
      a.type === b.type ? a.name.localeCompare(b.name) : a.type === "dir" ? -1 : 1
    );
    n.children?.forEach(sortRec);
  };
  sortRec(root);
  return root.children ?? [];
}

export function languageFor(path: string): string {
  const ext = path.split(".").pop()?.toLowerCase() ?? "";
  const map: Record<string, string> = {
    ts: "typescript",
    tsx: "typescript",
    js: "javascript",
    jsx: "javascript",
    mjs: "javascript",
    html: "html",
    htm: "html",
    css: "css",
    scss: "scss",
    json: "json",
    md: "markdown",
    py: "python",
    yml: "yaml",
    yaml: "yaml",
    txt: "plaintext",
  };
  if (path.endsWith(".d.ts")) return "typescript";
  return map[ext] ?? "plaintext";
}

const MAX_FILE_SIZE = 512 * 1024; // 512KB per file
const SKIP_DIRS = new Set(["node_modules", ".git", ".next", "dist", "build", ".cache", "vendor"]);

/** Recursively read a browser directory selection, preserving relative paths. */
export async function readFilesFromDirectory(dir: FileList): Promise<{ path: string; content: string }[]> {
  const out: { path: string; content: string }[] = [];
  const items = Array.from(dir) as File[];
  for (const file of items) {
    const rel = (file as File & { webkitRelativePath?: string }).webkitRelativePath || file.name;
    const parts = rel.split("/");
    // skip common non-source dirs at any depth
    if (parts.some((p) => SKIP_DIRS.has(p))) continue;
    if (file.size > MAX_FILE_SIZE) continue;
    try {
      const text = await file.text();
      out.push({ path: rel, content: text });
    } catch {
      // skip unreadable/binary files
    }
  }
  return out;
}

/** Strip the top-level folder name from paths (e.g. "smart-attendance/src/x" -> "src/x"). */
export function stripRootDir(files: { path: string; content: string }[]): { path: string; content: string }[] {
  if (files.length === 0) return files;
  const first = files[0].path.split("/")[0];
  const allShareRoot = files.every((f) => f.path.startsWith(first + "/"));
  if (!allShareRoot || !first) return files;
  return files.map((f) => ({ ...f, path: f.path.slice(first.length + 1) }));
}
