// RPL Forge — Core data models
// These types are shared across UI, application logic, and services.
// Production implementations (Firestore, GitHub, Vercel) should satisfy these same types.

export type User = {
  id: string;
  username: string;
  name: string;
  role: string; // e.g. "RPL Student"
  skills: string[];
  bio?: string;
  avatarColor: string;
};

export type ProjectStatus = "DRAFT" | "DEPLOYING" | "LIVE" | "FAILED";

export type Visibility = "public" | "private";

export type ProjectFile = {
  path: string; // relative path, e.g. "src/app/page.tsx"
  content: string;
  size: number;
  updatedAt: string; // ISO
};

export type Repository = {
  id: string;
  name: string; // e.g. rplforge-smart-attendance
  projectId: string;
  defaultBranch: string;
  createdAt: string;
};

export type Commit = {
  id: string;
  message: string;
  author: string;
  changedFiles: string[];
  createdAt: string;
};

export type Version = {
  id: string;
  label: string; // v1.0, v1.1 ...
  message: string;
  commitId: string;
  createdAt: string;
};

export type DeploymentStatus = "QUEUED" | "BUILDING" | "DEPLOYING" | "READY" | "FAILED";

export type DeploymentLog = {
  ts: string;
  line: string;
};

export type Deployment = {
  id: string;
  projectId: string;
  status: DeploymentStatus;
  url: string;
  commitId?: string;
  logs: DeploymentLog[];
  createdAt: string;
  readyAt?: string;
};

export type Project = {
  id: string;
  name: string;
  slug: string;
  description: string;
  ownerId: string;
  category: string;
  technologies: string[];
  visibility: Visibility;
  status: ProjectStatus;
  repository: Repository;
  deployment: Deployment | null;
  files: ProjectFile[];
  commits: Commit[];
  versions: Version[];
  screenshots: string[]; // data-URLs or placeholders
  createdAt: string;
  updatedAt: string;
};

export type Category =
  | "Web Development"
  | "IoT"
  | "Mobile"
  | "Game"
  | "Data Science"
  | "Other";

export const CATEGORIES: Category[] = [
  "Web Development",
  "IoT",
  "Mobile",
  "Game",
  "Data Science",
  "Other",
];

export type NewProjectInput = {
  name: string;
  description: string;
  category: string;
  technologies: string[];
  visibility: Visibility;
  files: { path: string; content: string }[];
};
