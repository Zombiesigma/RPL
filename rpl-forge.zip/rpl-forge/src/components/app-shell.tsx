"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { Anvil, Plus, LayoutDashboard, Compass, FolderKanban, Settings, User as UserIcon, LogOut, Menu, X } from "lucide-react";
import { useAuth } from "./auth-provider";
import { Button } from "./ui/button";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/projects", label: "Projects", icon: FolderKanban },
  { href: "/explore", label: "Explore", icon: Compass },
  { href: "/profile", label: "Profile", icon: UserIcon },
  { href: "/settings", label: "Settings", icon: Settings },
];

function Avatar({ name, color }: { name: string; color: string }) {
  return (
    <span
      className="inline-flex h-8 w-8 items-center justify-center rounded-full text-sm font-semibold text-white"
      style={{ backgroundColor: color }}
    >
      {name.charAt(0).toUpperCase()}
    </span>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const { user, logout, loading } = useAuth();
  const pathname = usePathname();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);

  const nav = (
    <nav className="flex flex-col gap-1">
      {NAV.map((item) => (
        <Link
          key={item.href}
          href={item.href}
          onClick={() => setMobileOpen(false)}
          className={cn(
            "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium text-zinc-600 hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-zinc-100",
            pathname.startsWith(item.href) && "bg-zinc-100 text-zinc-900 dark:bg-zinc-800 dark:text-zinc-100"
          )}
        >
          <item.icon className="h-4 w-4" />
          {item.label}
        </Link>
      ))}
    </nav>
  );

  return (
    <div className="min-h-screen bg-white dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100">
      {/* Top bar */}
      <header className="sticky top-0 z-40 border-b border-zinc-200 bg-white/90 backdrop-blur dark:border-zinc-800 dark:bg-zinc-950/90">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-3 px-4">
          <div className="flex items-center gap-3">
            <button className="md:hidden p-1" onClick={() => setMobileOpen((v) => !v)} aria-label="Menu">
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
            <Link href="/dashboard" className="flex items-center gap-2 font-semibold">
              <Anvil className="h-5 w-5 text-orange-600" />
              <span>RPL Forge</span>
            </Link>
          </div>
          <div className="flex items-center gap-2">
            {loading ? null : user ? (
              <>
                <Button size="sm" onClick={() => router.push("/projects/new")}>
                  <Plus className="h-4 w-4" /> New Project
                </Button>
                <div className="hidden sm:flex items-center gap-2 pl-2 border-l border-zinc-200 dark:border-zinc-800">
                  <Avatar name={user.name} color={user.avatarColor} />
                  <span className="text-sm">@{user.username}</span>
                  <button
                    onClick={async () => {
                      await logout();
                      router.push("/login");
                    }}
                    className="p-1.5 text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100"
                    aria-label="Log out"
                  >
                    <LogOut className="h-4 w-4" />
                  </button>
                </div>
              </>
            ) : null}
          </div>
        </div>
        {/* Mobile nav */}
        {mobileOpen && (
          <div className="border-t border-zinc-200 px-4 py-3 md:hidden dark:border-zinc-800">{nav}</div>
        )}
      </header>

      <div className="mx-auto flex max-w-7xl gap-8 px-4 py-6">
        {/* Sidebar (desktop) */}
        <aside className="hidden md:block w-52 shrink-0">
          <div className="sticky top-20">{nav}</div>
        </aside>
        <main className="min-w-0 flex-1">{children}</main>
      </div>
    </div>
  );
}
