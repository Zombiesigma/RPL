"use client";

import type { ProjectStatus } from "@/lib/types";
import { Badge } from "./ui/primitives";
import { Circle } from "lucide-react";

export function StatusBadge({ status }: { status: ProjectStatus | string }) {
  if (status === "LIVE")
    return (
      <Badge variant="live">
        <Circle className="h-2 w-2 fill-current" /> LIVE
      </Badge>
    );
  if (status === "DEPLOYING")
    return (
      <Badge variant="deploying">
        <Circle className="h-2 w-2 fill-current animate-pulse" /> DEPLOYING
      </Badge>
    );
  if (status === "FAILED")
    return (
      <Badge variant="failed">
        <Circle className="h-2 w-2 fill-current" /> FAILED
      </Badge>
    );
  return <Badge variant="outline">{status}</Badge>;
}
