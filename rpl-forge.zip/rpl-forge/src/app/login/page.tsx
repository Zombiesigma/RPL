"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Anvil, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/primitives";
import { useAuth } from "@/components/auth-provider";
import { authService } from "@/lib/services/auth";

export default function LoginPage() {
  const { user, loading, login } = useAuth();
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && user) router.replace("/dashboard");
  }, [user, loading, router]);

  const doLogin = async (name: string) => {
    setError("");
    setBusy(true);
    try {
      await login(name);
      router.push("/dashboard");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Login failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-zinc-950 px-4 text-zinc-100">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center gap-2 text-center">
          <Anvil className="h-10 w-10 text-orange-500" />
          <h1 className="text-2xl font-bold">Sign in to RPL Forge</h1>
          <p className="text-sm text-zinc-400">Pick a demo student to continue</p>
        </div>

        <div className="space-y-2">
          {authService.listDemoUsers().map((u) => (
            <button
              key={u.id}
              disabled={busy}
              onClick={() => doLogin(u.username)}
              className="flex w-full items-center gap-3 rounded-lg border border-zinc-800 bg-zinc-900/60 p-3 text-left transition-colors hover:border-zinc-700 hover:bg-zinc-900 disabled:opacity-50"
            >
              <span
                className="inline-flex h-10 w-10 items-center justify-center rounded-full font-semibold text-white"
                style={{ backgroundColor: u.avatarColor }}
              >
                {u.name[0]}
              </span>
              <span className="min-w-0">
                <span className="block font-medium">{u.name}</span>
                <span className="block text-xs text-zinc-400">@{u.username} · {u.role}</span>
              </span>
              {busy && <Loader2 className="ml-auto h-4 w-4 animate-spin text-zinc-500" />}
            </button>
          ))}
        </div>

        <form
          className="mt-6 flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            if (username.trim()) doLogin(username.trim());
          }}
        >
          <Input
            placeholder="or type a username…"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="border-zinc-800 bg-zinc-900"
          />
          <Button type="submit" disabled={busy || !username.trim()}>
            Go
          </Button>
        </form>
        {error && <p className="mt-3 text-sm text-red-400">{error}</p>}
      </div>
    </div>
  );
}
