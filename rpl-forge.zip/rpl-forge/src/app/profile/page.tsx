"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { FolderGit2, Globe, GitCommitHorizontal, Plus } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/primitives";
import { useAuth } from "@/components/auth-provider";
import { projectService } from "@/lib/services/project";
import type { Project } from "@/lib/types";
import { timeAgo } from "@/lib/utils";

export default function ProfilePage() {
  const { user, loading } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);

  useEffect(() => {
    if (user) setProjects(projectService.listByOwner(user.id));
  }, [user]);

  if (loading || !user) return null;

  const live = projects.filter((p) => p.status === "LIVE").length;
  const contributions = projects.reduce((a, p) => a + p.commits.length, 0);

  return (
    <AppShell>
      {/* Header card */}
      <div className="rounded-lg border border-zinc-800 bg-zinc-900/40 p-6">
        <div className="flex items-center gap-4">
          <span
            className="inline-flex h-16 w-16 items-center justify-center rounded-full text-2xl font-bold text-white"
            style={{ backgroundColor: user.avatarColor }}
          >
            {user.name[0]}
          </span>
          <div>
            <h1 className="text-xl font-bold">@{user.username}</h1>
            <p className="text-sm text-zinc-400">{user.name} · {user.role}</p>
          </div>
        </div>
        {user.bio && <p className="mt-4 text-sm text-zinc-300">{user.bio}</p>}
        <div className="mt-3 flex flex-wrap gap-1.5">
          {user.skills.map((s) => (
            <Badge key={s} variant="outline">{s}</Badge>
          ))}
        </div>
        <div className="mt-6 grid grid-cols-3 gap-3">
          <div className="rounded-md border border-zinc-800 p-3">
            <div className="flex items-center gap-2 text-xs text-zinc-400"><FolderGit2 className="h-3.5 w-3.5" /> Projects</div>
            <p className="mt-1 text-xl font-semibold">{projects.length}</p>
          </div>
          <div className="rounded-md border border-zinc-800 p-3">
            <div className="flex items-center gap-2 text-xs text-zinc-400"><Globe className="h-3.5 w-3.5" /> Live</div>
            <p className="mt-1 text-xl font-semibold">{live}</p>
          </div>
          <div className="rounded-md border border-zinc-800 p-3">
            <div className="flex items-center gap-2 text-xs text-zinc-400"><GitCommitHorizontal className="h-3.5 w-3.5" /> Contributions</div>
            <p className="mt-1 text-xl font-semibold">{contributions}</p>
          </div>
        </div>
      </div>

      {/* Projects */}
      <div className="mt-8 flex items-center justify-between">
        <h2 className="font-semibold">Projects</h2>
        <Link href="/projects/new">
          <Button size="sm" variant="outline" className="border-zinc-700">
            <Plus className="h-4 w-4" /> New
          </Button>
        </Link>
      </div>
      {projects.length === 0 ? (
        <div className="mt-4 rounded-lg border border-dashed border-zinc-800 p-10 text-center text-zinc-400">
          No projects yet.
        </div>
      ) : (
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((p) => (
            <Link
              key={p.id}
              href={`/projects/${p.id}`}
              className="group rounded-lg border border-zinc-800 bg-zinc-900/40 p-4 hover:border-zinc-700"
            >
              <div className="flex items-start justify-between gap-2">
                <h3 className="font-medium group-hover:text-orange-500">{p.name}</h3>
                <StatusBadge status={p.status} />
              </div>
              <p className="mt-1 line-clamp-2 text-sm text-zinc-400">{p.description}</p>
              <p className="mt-3 text-xs text-zinc-500">Updated {timeAgo(p.updatedAt)}</p>
            </Link>
          ))}
        </div>
      )}
    </AppShell>
  );
}
