"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/auth-provider";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Label, Input, Badge } from "@/components/ui/primitives";
import { authService } from "@/lib/services/auth";

export default function SettingsPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [name, setName] = useState("");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [user, loading, router]);

  useEffect(() => {
    if (user) setName(user.name);
  }, [user]);

  if (loading || !user) return null;

  return (
    <AppShell>
      <h1 className="text-2xl font-bold tracking-tight">Settings</h1>

      <div className="mt-6 max-w-xl space-y-6">
        <div className="rounded-lg border border-zinc-800 bg-zinc-900/40 p-5">
          <h2 className="font-medium">Profile</h2>
          <div className="mt-4 space-y-3">
            <div>
              <Label htmlFor="s-name">Display name</Label>
              <Input
                id="s-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1.5 border-zinc-800 bg-zinc-900"
              />
            </div>
            <div>
              <Label>Username</Label>
              <p className="mt-1.5 rounded-md border border-zinc-800 bg-zinc-950 px-3 py-2 text-sm text-zinc-400">
                @{user.username} <span className="text-xs">(fixed in this prototype)</span>
              </p>
            </div>
            <Button
              size="sm"
              onClick={() => {
                setSaved(true);
                setTimeout(() => setSaved(false), 1500);
              }}
            >
              {saved ? "✓ Saved" : "Save changes"}
            </Button>
          </div>
        </div>

        <div className="rounded-lg border border-zinc-800 bg-zinc-900/40 p-5">
          <h2 className="font-medium">Account</h2>
          <p className="mt-2 text-sm text-zinc-400">Signed in as</p>
          <p className="text-sm">{user.name} · {user.role}</p>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {user.skills.map((s) => (
              <Badge key={s} variant="outline">{s}</Badge>
            ))}
          </div>
          <Button
            size="sm"
            variant="destructive"
            className="mt-4"
            onClick={async () => {
              await authService.logout();
              router.push("/login");
            }}
          >
            Sign out
          </Button>
        </div>

        <div className="rounded-lg border border-zinc-800 bg-zinc-900/40 p-5 text-sm text-zinc-400">
          <h2 className="font-medium text-zinc-200">About this prototype</h2>
          <p className="mt-2">
            RPL Forge is a prototype. Authentication, repositories, and deployments are simulated —
            uploaded code is never executed. Production integrations (Firebase Auth, GitHub App,
            Vercel) plug into the same service interfaces.
          </p>
        </div>
      </div>
    </AppShell>
  );
}
