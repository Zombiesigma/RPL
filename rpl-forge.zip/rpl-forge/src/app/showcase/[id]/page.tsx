"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import QRCode from "qrcode";
import {
  ArrowLeft, ExternalLink, Copy, Check, QrCode, GitBranch, Rocket, GitCommitHorizontal, Users,
} from "lucide-react";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/primitives";
import { projectService } from "@/lib/services/project";
import { authService } from "@/lib/services/auth";
import type { Project } from "@/lib/types";
import { timeAgo } from "@/lib/utils";

export default function PublicProjectPage() {
  const params = useParams<{ id: string }>();
  const [project, setProject] = useState<Project | null>(null);
  const [copied, setCopied] = useState(false);
  const [qr, setQr] = useState<string | null>(null);
  const [showQr, setShowQr] = useState(false);

  useEffect(() => {
    if (params?.id) setProject(projectService.get(params.id));
  }, [params?.id]);

  if (!project) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-zinc-950 text-zinc-400">
        Project not found.{" "}
        <Link href="/explore" className="ml-1 text-orange-500 hover:underline">Explore</Link>
      </div>
    );
  }

  const owner = authService.listDemoUsers().find((u) => u.id === project.ownerId);
  const url = project.deployment?.url ?? `https://${project.slug}.rplforge.local`;

  const toggleQr = async () => {
    if (showQr) {
      setShowQr(false);
      return;
    }
    if (!qr) {
      const dataUrl = await QRCode.toDataURL(url, { width: 200, margin: 1 });
      setQr(dataUrl);
    }
    setShowQr(true);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <header className="border-b border-zinc-800/60">
        <div className="mx-auto flex h-14 max-w-4xl items-center px-4">
          <Link href="/explore" className="flex items-center gap-1.5 text-sm text-zinc-400 hover:text-zinc-100">
            <ArrowLeft className="h-4 w-4" /> Explore
          </Link>
          <span className="ml-auto text-sm font-semibold text-orange-500">RPL Forge</span>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-4 py-10">
        {/* Showcase header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-bold tracking-tight">{project.name}</h1>
              <StatusBadge status={project.status} />
            </div>
            <p className="mt-2 text-sm text-zinc-400">
              by <Link href="/profile" className="text-zinc-200 hover:underline">@{owner?.username ?? "student"}</Link>
              {" "}· {project.category} · v{project.versions[0]?.label.replace("v", "") ?? "1.0"} · updated {timeAgo(project.updatedAt)}
            </p>
          </div>
        </div>

        <p className="mt-4 max-w-2xl text-lg text-zinc-300">{project.description}</p>

        <div className="mt-4 flex flex-wrap gap-1.5">
          {project.technologies.map((t) => (
            <Badge key={t} variant="outline">{t}</Badge>
          ))}
        </div>

        {/* Screenshot placeholder */}
        <div className="mt-8 flex h-56 items-center justify-center rounded-xl border border-zinc-800 bg-gradient-to-br from-zinc-900 to-zinc-950">
          <span className="font-mono text-sm text-zinc-600">▲ live preview · {project.slug}.rplforge.local</span>
        </div>

        {/* Live URL + actions */}
        <div className="mt-6 flex flex-col gap-3 rounded-lg border border-zinc-800 bg-zinc-900/60 p-4 sm:flex-row sm:items-center">
          <span className="flex-1 truncate font-mono text-sm text-emerald-400">{url}</span>
          <div className="flex gap-2">
            <Button
              size="sm"
              onClick={() => window.open("https://" + project.slug + ".rplforge.local", "_blank")}
            >
              <ExternalLink className="h-4 w-4" /> Visit Live Website
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="border-zinc-700"
              onClick={() => {
                navigator.clipboard?.writeText(url);
                setCopied(true);
                setTimeout(() => setCopied(false), 1500);
              }}
            >
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />} Copy Link
            </Button>
            <Button size="sm" variant="outline" className="border-zinc-700" onClick={toggleQr}>
              <QrCode className="h-4 w-4" /> QR Code
            </Button>
          </div>
        </div>

        {showQr && qr && (
          <div className="mt-4 flex justify-center rounded-lg border border-zinc-800 bg-white p-4 w-fit mx-auto">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={qr} alt={`QR code for ${url}`} width={200} height={200} />
          </div>
        )}

        {/* Meta */}
        <div className="mt-8 grid gap-3 sm:grid-cols-3">
          <div className="rounded-lg border border-zinc-800 bg-zinc-900/40 p-4">
            <div className="flex items-center gap-2 text-sm text-zinc-400"><GitBranch className="h-4 w-4" /> Repository</div>
            <p className="mt-2 font-mono text-sm">{project.repository.name}</p>
          </div>
          <div className="rounded-lg border border-zinc-800 bg-zinc-900/40 p-4">
            <div className="flex items-center gap-2 text-sm text-zinc-400"><Rocket className="h-4 w-4" /> Deployment</div>
            <p className="mt-2 text-sm">{project.deployment?.status ?? "READY"}</p>
          </div>
          <div className="rounded-lg border border-zinc-800 bg-zinc-900/40 p-4">
            <div className="flex items-center gap-2 text-sm text-zinc-400"><GitCommitHorizontal className="h-4 w-4" /> Versions</div>
            <p className="mt-2 text-sm">{project.versions.length} releases</p>
          </div>
        </div>

        {/* Contributors */}
        <div className="mt-8">
          <h2 className="flex items-center gap-2 font-semibold"><Users className="h-4 w-4" /> Contributors</h2>
          <div className="mt-3 flex items-center gap-3">
            <span
              className="inline-flex h-9 w-9 items-center justify-center rounded-full text-sm font-semibold text-white"
              style={{ backgroundColor: owner?.avatarColor ?? "#52525b" }}
            >
              {owner?.name[0] ?? "?"}
            </span>
            <div>
              <p className="text-sm font-medium">{owner?.name}</p>
              <p className="text-xs text-zinc-500">@{owner?.username}</p>
            </div>
          </div>
        </div>

        {/* Changelog */}
        <div className="mt-8">
          <h2 className="font-semibold">Changelog</h2>
          <ul className="mt-3 space-y-2">
            {[...project.versions]
              .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
              .map((v) => (
                <li key={v.id} className="flex items-baseline gap-3 rounded-md border border-zinc-800/60 px-3 py-2">
                  <span className="font-mono text-sm text-orange-500">{v.label}</span>
                  <span className="text-sm text-zinc-300">{v.message}</span>
                  <span className="ml-auto text-xs text-zinc-500">{timeAgo(v.createdAt)}</span>
                </li>
              ))}
          </ul>
        </div>
      </main>

      <footer className="border-t border-zinc-800/60 py-8 text-center text-sm text-zinc-500">
        Forged with RPL Forge
      </footer>
    </div>
  );
}
