"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft, FolderOpen, File, FileCode, FileJson, FileText,
  Loader2, CheckCircle2, PartyPopper, ExternalLink, Code2, Rocket, AlertCircle,
} from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Input, Textarea, Select, Label } from "@/components/ui/primitives";
import { useAuth } from "@/components/auth-provider";
import { projectService } from "@/lib/services/project";
import { readFilesFromDirectory, stripRootDir, buildTree, type TreeNode } from "@/lib/services/fileService";
import { CATEGORIES, type NewProjectInput, type Project } from "@/lib/types";
import { cn, formatBytes } from "@/lib/utils";

type Stage = "form" | "processing" | "done";

const PIPELINE_STEPS = [
  { label: "Reading files…", done: "Files loaded" },
  { label: "Validating project…", done: "Project valid" },
  { label: "Creating repository…", done: "Repository created" },
  { label: "Preparing hosting…", done: "Hosting prepared" },
  { label: "Deploying…", done: "Deployment ready" },
];

function FileIcon({ node }: { node: TreeNode }) {
  if (node.type === "dir") return <FolderOpen className="h-4 w-4 text-orange-500/80" />;
  const ext = node.name.split(".").pop();
  if (ext === "json") return <FileJson className="h-4 w-4 text-amber-500" />;
  if (["ts", "tsx", "js", "jsx", "html", "css"].includes(ext ?? ""))
    return <FileCode className="h-4 w-4 text-sky-500" />;
  if (ext === "md") return <FileText className="h-4 w-4 text-zinc-400" />;
  return <File className="h-4 w-4 text-zinc-500" />;
}

function TreeView({ nodes, depth = 0 }: { nodes: TreeNode[]; depth?: number }) {
  return (
    <ul className={cn(depth > 0 && "ml-4 border-l border-zinc-800 pl-3")}>
      {nodes.map((n) => (
        <li key={n.path} className="py-0.5">
          <span className="flex items-center gap-1.5 text-sm text-zinc-300">
            <FileIcon node={n} />
            {n.name}
          </span>
          {n.children && n.children.length > 0 && <TreeView nodes={n.children} depth={depth + 1} />}
        </li>
      ))}
    </ul>
  );
}

export default function NewProjectPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [stage, setStage] = useState<Stage>("form");
  const [stepIdx, setStepIdx] = useState(-1);
  const [stepDone, setStepDone] = useState<boolean[]>([]);
  const [error, setError] = useState("");
  const [created, setCreated] = useState<Project | null>(null);

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<string>(CATEGORIES[0]);
  const [technologies, setTechnologies] = useState("");
  const [visibility, setVisibility] = useState<"public" | "private">("public");
  const [files, setFiles] = useState<{ path: string; content: string }[]>([]);
  const [folderName, setFolderName] = useState("");

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [user, loading, router]);

  const pickFolder = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return;
    const raw = await readFilesFromDirectory(e.target.files);
    if (raw.length === 0) {
      setError("No readable source files found in that folder.");
      return;
    }
    const cleaned = stripRootDir(raw);
    const first = raw[0].path.split("/")[0];
    setFolderName(first);
    setFiles(cleaned);
    if (!name) setName(first.replace(/[-_]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()));
    setError("");
  };

  const totalSize = files.reduce((a, f) => a + f.content.length, 0);

  const submit = async () => {
    if (!user) return;
    if (!name.trim() || files.length === 0) {
      setError("Give your project a name and choose a project folder first.");
      return;
    }
    setError("");
    setStage("processing");
    setStepIdx(0);
    setStepDone(PIPELINE_STEPS.map(() => false));

    const advance = (i: number) =>
      new Promise<void>((r) =>
        setTimeout(() => {
          setStepDone((prev) => prev.map((v, j) => (j < i ? true : v)));
          setStepIdx(i);
          r();
        }, 900)
      );

    await advance(0); // reading files
    await advance(1); // validating
    await advance(2); // repository
    await advance(3); // hosting
    await advance(4); // deploying
    setStepDone(PIPELINE_STEPS.map(() => true));

    const input: NewProjectInput = {
      name: name.trim(),
      description: description.trim(),
      category,
      technologies: technologies.split(",").map((t) => t.trim()).filter(Boolean),
      visibility,
      files,
    };
    const project = await projectService.create(input, user.id);
    setCreated(project);
    setStage("done");
  };

  return (
    <AppShell>
      <button
        onClick={() => router.back()}
        className="mb-4 flex items-center gap-1.5 text-sm text-zinc-400 hover:text-zinc-100"
      >
        <ArrowLeft className="h-4 w-4" /> Back
      </button>

      <AnimatePresence mode="wait">
        {stage === "form" && (
          <motion.div key="form" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <h1 className="text-2xl font-bold tracking-tight">New Project</h1>
            <p className="mt-1 text-sm text-zinc-400">
              Fill in the details, choose your project folder, and go live.
            </p>

            <div className="mt-6 grid gap-8 lg:grid-cols-2">
              {/* Left: form */}
              <div className="space-y-4">
                <div>
                  <Label htmlFor="pname">Project Name</Label>
                  <Input
                    id="pname"
                    placeholder="e.g. Smart Attendance"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="mt-1.5 border-zinc-800 bg-zinc-900"
                  />
                </div>
                <div>
                  <Label htmlFor="pdesc">Description</Label>
                  <Textarea
                    id="pdesc"
                    placeholder="What does your project do?"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="mt-1.5 border-zinc-800 bg-zinc-900"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="pcat">Category</Label>
                    <Select
                      id="pcat"
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="mt-1.5 border-zinc-800 bg-zinc-900"
                    >
                      {CATEGORIES.map((c) => (
                        <option key={c}>{c}</option>
                      ))}
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="pvis">Visibility</Label>
                    <Select
                      id="pvis"
                      value={visibility}
                      onChange={(e) => setVisibility(e.target.value as "public" | "private")}
                      className="mt-1.5 border-zinc-800 bg-zinc-900"
                    >
                      <option value="public">Public</option>
                      <option value="private">Private</option>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="ptech">Technologies</Label>
                  <Input
                    id="ptech"
                    placeholder="Next.js, Firebase, ESP32 (comma separated)"
                    value={technologies}
                    onChange={(e) => setTechnologies(e.target.value)}
                    className="mt-1.5 border-zinc-800 bg-zinc-900"
                  />
                </div>

                <div className="rounded-lg border border-dashed border-zinc-700 p-6 text-center">
                  <input
                    ref={inputRef}
                    type="file"
                    className="hidden"
                    onChange={pickFolder}
                    // @ts-expect-error non-standard but supported in Chromium/WebKit
                    webkitdirectory=""
                    directory=""
                    multiple
                  />
                  <FolderOpen className="mx-auto h-8 w-8 text-zinc-500" />
                  <p className="mt-2 text-sm font-medium">Choose Project Folder</p>
                  <p className="mt-1 text-xs text-zinc-500">
                    We&apos;ll keep your file structure exactly as-is
                  </p>
                  <Button variant="secondary" size="sm" className="mt-3" onClick={() => inputRef.current?.click()}>
                    Browse folder…
                  </Button>
                  {files.length > 0 && (
                    <p className="mt-3 text-sm text-emerald-500">
                      ✓ {folderName}/ — {files.length} files ({formatBytes(totalSize)})
                    </p>
                  )}
                </div>

                {error && (
                  <p className="flex items-center gap-1.5 text-sm text-red-400">
                    <AlertCircle className="h-4 w-4" /> {error}
                  </p>
                )}

                <Button className="w-full" onClick={submit}>
                  <Rocket className="h-4 w-4" /> Upload &amp; Deploy
                </Button>
              </div>

              {/* Right: preview */}
              <div className="rounded-lg border border-zinc-800 bg-zinc-900/40 p-4">
                <h3 className="text-sm font-medium text-zinc-300">Upload preview</h3>
                {files.length === 0 ? (
                  <p className="mt-8 text-center text-sm text-zinc-500">
                    Select a folder to preview its structure
                  </p>
                ) : (
                  <>
                    <p className="mt-1 font-mono text-xs text-zinc-500">{folderName}/</p>
                    <div className="mt-2 max-h-[420px] overflow-auto">
                      <TreeView nodes={buildTree(files.map((f) => ({ ...f, size: f.content.length, updatedAt: "" })))} />
                    </div>
                  </>
                )}
              </div>
            </div>
          </motion.div>
        )}

        {stage === "processing" && (
          <motion.div
            key="processing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="mx-auto max-w-md py-12"
          >
            <h1 className="text-center text-2xl font-bold">Deploying your project</h1>
            <div className="mt-8 space-y-4">
              {PIPELINE_STEPS.map((s, i) => {
                const isDone = stepDone[i];
                const active = stepIdx === i;
                return (
                  <div key={s.label} className="flex items-center gap-3">
                    {isDone ? (
                      <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                    ) : active ? (
                      <Loader2 className="h-5 w-5 animate-spin text-orange-500" />
                    ) : (
                      <span className="h-5 w-5 rounded-full border border-zinc-700" />
                    )}
                    <span className={cn("text-sm", isDone ? "text-zinc-300" : active ? "text-zinc-100" : "text-zinc-600")}>
                      {isDone ? `✓ ${s.done}` : active ? s.label : s.label.replace("…", "")}
                    </span>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}

        {stage === "done" && created && (
          <motion.div
            key="done"
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mx-auto max-w-lg py-12 text-center"
          >
            <PartyPopper className="mx-auto h-12 w-12 text-orange-500" />
            <h1 className="mt-4 text-2xl font-bold">Your project is live!</h1>
            <p className="mt-2 text-lg font-medium text-zinc-200">{created.name}</p>
            <div className="mt-4 rounded-lg border border-zinc-800 bg-zinc-900/60 px-4 py-3 font-mono text-sm text-emerald-400">
              {created.deployment?.url}
            </div>
            <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
              <Button onClick={() => window.open("https://" + created.slug + ".rplforge.local", "_blank")}>
                <ExternalLink className="h-4 w-4" /> Open Website
              </Button>
              <Button variant="secondary" onClick={() => router.push(`/projects/${created.id}/workspace`)}>
                <Code2 className="h-4 w-4" /> Open Workspace
              </Button>
            </div>
            <button
              onClick={() => router.push(`/projects/${created.id}`)}
              className="mt-4 text-sm text-zinc-400 hover:text-zinc-100"
            >
              View project details
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </AppShell>
  );
}
