"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Plus, Search } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Badge, Input } from "@/components/ui/primitives";
import { useAuth } from "@/components/auth-provider";
import { projectService } from "@/lib/services/project";
import type { Project } from "@/lib/types";
import { timeAgo } from "@/lib/utils";

export default function ProjectsPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [projects, setProjects] = useState<Project[]>([]);
  const [query, setQuery] = useState("");

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [user, loading, router]);

  useEffect(() => {
    if (user) setProjects(projectService.listByOwner(user.id));
  }, [user]);

  if (loading || !user) return null;

  const filtered = projects.filter(
    (p) =>
      p.name.toLowerCase().includes(query.toLowerCase()) ||
      p.description.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <AppShell>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold tracking-tight">Projects</h1>
        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-zinc-500" />
            <Input
              placeholder="Search projects…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-56 border-zinc-800 bg-zinc-900 pl-8"
            />
          </div>
          <Button onClick={() => router.push("/projects/new")}>
            <Plus className="h-4 w-4" /> New Project
          </Button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="mt-8 rounded-lg border border-dashed border-zinc-800 p-12 text-center text-zinc-400">
          {projects.length === 0 ? "No projects yet." : "No projects match your search."}
        </div>
      ) : (
        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p) => (
            <Link
              key={p.id}
              href={`/projects/${p.id}`}
              className="group rounded-lg border border-zinc-800 bg-zinc-900/40 p-4 transition-colors hover:border-zinc-700"
            >
              <div className="flex items-start justify-between gap-2">
                <h3 className="font-medium group-hover:text-orange-500">{p.name}</h3>
                <StatusBadge status={p.status} />
              </div>
              <p className="mt-1 line-clamp-2 text-sm text-zinc-400">{p.description}</p>
              <div className="mt-3 flex flex-wrap gap-1">
                {p.technologies.slice(0, 4).map((t) => (
                  <Badge key={t} variant="outline">
                    {t}
                  </Badge>
                ))}
              </div>
              <div className="mt-3 flex items-center justify-between text-xs text-zinc-500">
                <span>{p.repository.name}</span>
                <span>{timeAgo(p.updatedAt)}</span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </AppShell>
  );
}
