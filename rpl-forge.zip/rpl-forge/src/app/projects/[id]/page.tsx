"use client";

import { useRouter, useParams } from "next/navigation";
import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowLeft, ExternalLink, Code2, GitBranch, History, Globe, Copy, Check,
  GitCommitHorizontal, Users, Rocket,
} from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/primitives";
import { useAuth } from "@/components/auth-provider";
import { projectService } from "@/lib/services/project";
import type { Project } from "@/lib/types";
import { timeAgo } from "@/lib/utils";

export default function ProjectDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const { user, loading } = useAuth();
  const [project, setProject] = useState<Project | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [user, loading, router]);

  useEffect(() => {
    if (params?.id) setProject(projectService.get(params.id));
  }, [params?.id]);

  if (loading || !user) return null;
  if (!project) {
    return (
      <AppShell>
        <div className="py-16 text-center text-zinc-400">
          Project not found.{" "}
          <Link href="/projects" className="text-orange-500 hover:underline">
            Back to projects
          </Link>
        </div>
      </AppShell>
    );
  }

  const owner = user;
  const url = project.deployment?.url ?? "";
  const versions = [...project.versions].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  return (
    <AppShell>
      <button
        onClick={() => router.back()}
        className="mb-4 flex items-center gap-1.5 text-sm text-zinc-400 hover:text-zinc-100"
      >
        <ArrowLeft className="h-4 w-4" /> Back
      </button>

      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold tracking-tight">{project.name}</h1>
            <StatusBadge status={project.status} />
          </div>
          <p className="mt-1 text-sm text-zinc-400">
            by <span className="text-zinc-300">@{owner.username}</span> · {project.category} · updated {timeAgo(project.updatedAt)}
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            className="border-zinc-700"
            onClick={() => window.open("https://" + project.slug + ".rplforge.local", "_blank")}
          >
            <ExternalLink className="h-4 w-4" /> Open Website
          </Button>
          <Button onClick={() => router.push(`/projects/${project.id}/workspace`)}>
            <Code2 className="h-4 w-4" /> Open Workspace
          </Button>
        </div>
      </div>

      <p className="mt-4 max-w-3xl text-zinc-300">{project.description}</p>

      <div className="mt-4 flex flex-wrap gap-1.5">
        {project.technologies.map((t) => (
          <Badge key={t} variant="outline">
            {t}
          </Badge>
        ))}
      </div>

      {/* Live URL bar */}
      {url && (
        <div className="mt-6 flex items-center gap-3 rounded-lg border border-zinc-800 bg-zinc-900/60 px-4 py-3">
          <Globe className="h-4 w-4 text-emerald-500" />
          <span className="flex-1 truncate font-mono text-sm text-emerald-400">{url}</span>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => {
              navigator.clipboard?.writeText(url);
              setCopied(true);
              setTimeout(() => setCopied(false), 1500);
            }}
          >
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
          </Button>
        </div>
      )}

      {/* Meta grid */}
      <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-lg border border-zinc-800 bg-zinc-900/40 p-4">
          <div className="flex items-center gap-2 text-sm text-zinc-400">
            <GitBranch className="h-4 w-4" /> Repository
          </div>
          <p className="mt-2 font-mono text-sm">{project.repository.name}</p>
          <p className="text-xs text-zinc-500">branch: {project.repository.defaultBranch}</p>
        </div>
        <div className="rounded-lg border border-zinc-800 bg-zinc-900/40 p-4">
          <div className="flex items-center gap-2 text-sm text-zinc-400">
            <Rocket className="h-4 w-4" /> Deployment
          </div>
          <p className="mt-2 font-mono text-xs text-zinc-300">{project.deployment?.id.slice(0, 12)}</p>
          <p className="text-xs text-zinc-500">{project.deployment?.status}</p>
        </div>
        <div className="rounded-lg border border-zinc-800 bg-zinc-900/40 p-4">
          <div className="flex items-center gap-2 text-sm text-zinc-400">
            <GitCommitHorizontal className="h-4 w-4" /> Commits
          </div>
          <p className="mt-2 text-2xl font-semibold">{project.commits.length}</p>
          <p className="text-xs text-zinc-500">on {project.repository.defaultBranch}</p>
        </div>
        <div className="rounded-lg border border-zinc-800 bg-zinc-900/40 p-4">
          <div className="flex items-center gap-2 text-sm text-zinc-400">
            <Users className="h-4 w-4" /> Contributors
          </div>
          <div className="mt-2 flex items-center gap-2">
            <span
              className="inline-flex h-7 w-7 items-center justify-center rounded-full text-xs font-semibold text-white"
              style={{ backgroundColor: owner.avatarColor }}
            >
              {owner.name[0]}
            </span>
            <span className="text-sm">@{owner.username}</span>
          </div>
        </div>
      </div>

      {/* Version history */}
      <div className="mt-8">
        <h2 className="flex items-center gap-2 font-semibold">
          <History className="h-4 w-4" /> Version history
        </h2>
        <div className="mt-3 space-y-0">
          {versions.map((v, i) => (
            <motion.div
              key={v.id}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.04 }}
              className="relative flex gap-4 pb-6 pl-1"
            >
              <div className="flex flex-col items-center">
                <span className="mt-1 h-2.5 w-2.5 rounded-full bg-orange-500" />
                {i < versions.length - 1 && <span className="mt-1 w-px flex-1 bg-zinc-800" />}
              </div>
              <div>
                <p className="font-mono text-sm font-medium text-orange-500">{v.label}</p>
                <p className="text-sm text-zinc-200">{v.message}</p>
                <p className="text-xs text-zinc-500">{timeAgo(v.createdAt)}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
