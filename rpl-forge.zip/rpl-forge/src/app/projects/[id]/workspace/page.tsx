"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Editor from "@monaco-editor/react";
import {
  ChevronRight, ChevronDown, File as FileIcon, FileCode, FileJson, FileText, Folder, FolderOpen,
  Plus, Trash2, PenLine, Save, Rocket, Loader2, Circle, Search, X, FolderPlus,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/status-badge";
import { useAuth } from "@/components/auth-provider";
import { projectService } from "@/lib/services/project";
import { buildTree, languageFor, type TreeNode } from "@/lib/services/fileService";
import { repositoryService, nextVersion } from "@/lib/services/repository";
import { runPipeline } from "@/lib/services/deployment";
import type { Project, ProjectFile } from "@/lib/types";
import { cn } from "@/lib/utils";

/* ------------------------------ File tree ------------------------------ */

function iconFor(node: TreeNode, open: boolean) {
  if (node.type === "dir") return open ? <FolderOpen className="h-4 w-4 text-orange-500/80" /> : <Folder className="h-4 w-4 text-orange-500/80" />;
  const ext = node.name.split(".").pop();
  if (ext === "json") return <FileJson className="h-4 w-4 text-amber-500" />;
  if (["ts", "tsx", "js", "jsx", "html", "css"].includes(ext ?? "")) return <FileCode className="h-4 w-4 text-sky-500" />;
  if (ext === "md") return <FileText className="h-4 w-4 text-zinc-400" />;
  return <FileIcon className="h-4 w-4 text-zinc-500" />;
}

function TreeRow({
  node,
  depth,
  openDirs,
  toggleDir,
  activePath,
  onOpen,
  dirty,
}: {
  node: TreeNode;
  depth: number;
  openDirs: Set<string>;
  toggleDir: (p: string) => void;
  activePath: string | null;
  onOpen: (p: string) => void;
  dirty: Set<string>;
}) {
  const open = openDirs.has(node.path);
  return (
    <div>
      <button
        className={cn(
          "flex w-full items-center gap-1 rounded px-1.5 py-1 text-left text-sm hover:bg-zinc-800/70",
          activePath === node.path && "bg-zinc-800 text-orange-400"
        )}
        style={{ paddingLeft: 6 + depth * 14 }}
        onClick={() => (node.type === "dir" ? toggleDir(node.path) : onOpen(node.path))}
      >
        {node.type === "dir" ? (
          open ? <ChevronDown className="h-3.5 w-3.5 text-zinc-500" /> : <ChevronRight className="h-3.5 w-3.5 text-zinc-500" />
        ) : null}
        {iconFor(node, open)}
        <span className="truncate">{node.name}</span>
        {dirty.has(node.path) && <Circle className="ml-auto h-2 w-2 shrink-0 fill-orange-400 text-orange-400" />}
      </button>
      {node.type === "dir" && open && node.children?.map((c) => (
        <TreeRow key={c.path} node={c} depth={depth + 1} openDirs={openDirs} toggleDir={toggleDir} activePath={activePath} onOpen={onOpen} dirty={dirty} />
      ))}
    </div>
  );
}

/* ------------------------------ Workspace ------------------------------ */

type Tab = { path: string; content: string };

export default function WorkspacePage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const { user, loading } = useAuth();
  const [project, setProject] = useState<Project | null>(null);
  const [tabs, setTabs] = useState<Tab[]>([]);
  const [activePath, setActivePath] = useState<string | null>(null);
  const [dirty, setDirty] = useState<Set<string>>(new Set());
  const [openDirs, setOpenDirs] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState("");
  const [saving, setSaving] = useState(false);
  const [committing, setCommitting] = useState(false);
  const [commitStatus, setCommitStatus] = useState<{ msg: string; done: boolean } | null>(null);
  const [deployStatus, setDeployStatus] = useState<string | null>(null);
  const [toast, setToast] = useState("");

  // load project
  useEffect(() => {
    if (params?.id) {
      const p = projectService.get(params.id);
      if (p) {
        setProject(p);
        const readme = p.files.find((f) => f.path === "README.md") ?? p.files[0];
        if (readme) {
          setTabs([{ path: readme.path, content: readme.content }]);
          setActivePath(readme.path);
        }
        const dirs = new Set<string>();
        p.files.forEach((f) => {
          const parts = f.path.split("/");
          for (let i = 1; i < parts.length; i++) dirs.add(parts.slice(0, i).join("/"));
        });
        setOpenDirs(dirs);
      }
    }
  }, [params?.id]);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [user, loading, router]);

  const files: ProjectFile[] = useMemo(() => project?.files ?? [], [project]);
  const tree = useMemo(() => {
    const filtered = search
      ? files.filter((f) => f.path.toLowerCase().includes(search.toLowerCase()))
      : files;
    return buildTree(filtered);
  }, [files, search]);

  const openFile = useCallback((path: string) => {
    if (!project) return;
    const f = project.files.find((x) => x.path === path);
    if (!f) return;
    setTabs((prev) => (prev.some((t) => t.path === path) ? prev : [...prev, { path, content: f.content }]));
    setActivePath(path);
  }, [project]);

  const activeTab = tabs.find((t) => t.path === activePath) ?? null;

  const updateContent = (content: string) => {
    if (!activeTab) return;
    setTabs((prev) => prev.map((t) => (t.path === activeTab.path ? { ...t, content } : t)));
    setDirty((prev) => new Set(prev).add(activeTab.path));
  };

  const saveActive = async () => {
    if (!project || !activeTab) return;
    setSaving(true);
    await new Promise((r) => setTimeout(r, 400));
    const newFiles = repositoryService.writeFile(project, activeTab.path, activeTab.content);
    const updated = projectService.update(project.id, { files: newFiles });
    if (updated) setProject(updated);
    setDirty((prev) => {
      const n = new Set(prev);
      n.delete(activeTab.path);
      return n;
    });
    setSaving(false);
    showToast("✓ File saved");
  };

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(""), 2000);
  };

  const commitAndDeploy = async () => {
    if (!project || !user) return;
    setCommitting(true);
    try {
      // save all dirty tabs
      let cur = project;
      let newFiles = cur.files;
      for (const t of tabs) {
        if (dirty.has(t.path)) {
          newFiles = repositoryService.writeFile(cur, t.path, t.content);
        }
      }
      const changedFiles = tabs.filter((t) => dirty.has(t.path)).map((t) => t.path);
      const saved = projectService.update(project.id, { files: newFiles });
      if (saved) cur = saved;
      setDirty(new Set());
      setProject({ ...cur });
      setCommitStatus({ msg: "Saving changes…", done: false });
      await new Promise((r) => setTimeout(r, 700));
      setCommitStatus({ msg: "✓ Changes saved", done: true });

      setCommitStatus({ msg: "Creating commit…", done: false });
      await new Promise((r) => setTimeout(r, 800));
      const commit = repositoryService.createCommit(
        cur,
        changedFiles.length > 0
          ? `Update ${changedFiles.join(", ")}`
          : "Manual deploy",
        user.username,
        changedFiles.length > 0 ? changedFiles : [activePath ?? "src/app/page.tsx"]
      );
      const withCommit = projectService.addCommit(project.id, commit);
      const version: { id: string; label: string; message: string; commitId: string; createdAt: string } = {
        id: `ver-${Date.now().toString(36)}`,
        label: nextVersion(cur.versions),
        message: commit.message,
        commitId: commit.id,
        createdAt: commit.createdAt,
      };
      const withVersion = withCommit ? projectService.addVersion(project.id, version) : null;
      cur = withVersion ?? cur;
      setCommitStatus({ msg: "✓ Commit created", done: true });

      // deploy pipeline
      const dep = { id: `dpl-${Date.now().toString(36)}`, projectId: project.id, status: "QUEUED" as const, url: cur.deployment?.url ?? "", logs: [], createdAt: new Date().toISOString() };
      const final = await runPipeline(cur, dep, (status) => setDeployStatus(status));
      projectService.update(project.id, { status: "LIVE", deployment: final });
      setProject((prev) => (prev ? { ...prev, status: "LIVE", deployment: final } : prev));
      setCommitStatus({ msg: "🟢 Website updated", done: true });
      showToast("🟢 Website updated");
    } finally {
      setTimeout(() => {
        setCommitting(false);
        setCommitStatus(null);
        setDeployStatus(null);
      }, 1800);
    }
  };

  const createFile = async (isDir = false) => {
    if (!project) return;
    const name = prompt(isDir ? "New folder path (e.g. src/utils):" : "New file path (e.g. src/utils/helpers.ts):");
    if (!name) return;
    try {
      if (isDir) {
        const seedPath = name.replace(/\/$/, "") + "/.gitkeep";
        const nf = repositoryService.createFile(project, seedPath, "");
        setProject(projectService.update(project.id, { files: nf }));
        setOpenDirs((prev) => new Set(prev).add(name.replace(/\/$/, "")));
      } else {
        const nf = repositoryService.createFile(project, name, "");
        setProject(projectService.update(project.id, { files: nf }));
        openFile(name);
      }
    } catch (e) {
      alert(e instanceof Error ? e.message : "Failed to create");
    }
  };

  const renameFile = (path: string) => {
    if (!project) return;
    const next = prompt("Rename to:", path);
    if (!next || next === path) return;
    try {
      const nf = repositoryService.renameFile(project, path, next);
      setProject(projectService.update(project.id, { files: nf }));
      setTabs((prev) => prev.map((t) => (t.path === path ? { ...t, path: next } : t)));
      setActivePath((p) => (p === path ? next : p));
    } catch (e) {
      alert(e instanceof Error ? e.message : "Rename failed");
    }
  };

  const deleteFile = (path: string) => {
    if (!project || !confirm(`Delete ${path}?`)) return;
    const nf = repositoryService.deleteFile(project, path);
    setProject(projectService.update(project.id, { files: nf }));
    setTabs((prev) => prev.filter((t) => !t.path.startsWith(path)));
    setActivePath((p) => (p && p.startsWith(path) ? null : p));
  };

  const closeTab = (path: string) => {
    setTabs((prev) => prev.filter((t) => t.path !== path));
    setActivePath((p) => (p === path ? null : p));
  };

  if (loading || !user) return null;
  if (!project) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-zinc-950 text-zinc-400">
        Project not found.
      </div>
    );
  }

  const monacoLang = activePath ? languageFor(activePath) : "plaintext";

  return (
    <div className="flex h-screen flex-col bg-zinc-950 text-zinc-100">
      {/* Top bar */}
      <div className="flex h-12 shrink-0 items-center justify-between gap-2 border-b border-zinc-800 px-3">
        <div className="flex min-w-0 items-center gap-2">
          <button onClick={() => router.push(`/projects/${project.id}`)} className="text-sm text-zinc-400 hover:text-zinc-100">
            ←
          </button>
          <span className="truncate font-medium">{project.name}</span>
          <StatusBadge status={project.status} />
          <span className="hidden font-mono text-xs text-zinc-500 sm:inline">{project.repository.name}</span>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="secondary" onClick={saveActive} disabled={!activeTab || saving || committing}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            <span className="hidden sm:inline">Save</span>
          </Button>
          <Button size="sm" onClick={commitAndDeploy} disabled={committing}>
            {committing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Rocket className="h-4 w-4" />}
            <span className="hidden sm:inline">Commit &amp; Deploy</span>
          </Button>
        </div>
      </div>

      {/* status strip */}
      {(commitStatus || deployStatus) && (
        <div className="flex h-8 shrink-0 items-center gap-3 border-b border-zinc-800 bg-zinc-900/70 px-4 text-xs">
          {commitStatus && (
            <span className={cn(commitStatus.done ? "text-emerald-400" : "text-zinc-300")}>{commitStatus.msg}</span>
          )}
          {deployStatus && (
            <span className="flex items-center gap-1.5 text-amber-400">
              <Circle className="h-2 w-2 fill-current animate-pulse" />
              {deployStatus}
            </span>
          )}
        </div>
      )}

      <div className="flex min-h-0 flex-1">
        {/* Sidebar: file explorer */}
        <div className="flex w-60 shrink-0 flex-col border-r border-zinc-800 bg-zinc-900/40">
          <div className="flex items-center gap-1 border-b border-zinc-800 px-2 py-2">
            <div className="relative flex-1">
              <Search className="absolute left-2 top-1.5 h-3.5 w-3.5 text-zinc-500" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search files…"
                className="w-full rounded border border-zinc-800 bg-zinc-950 py-1 pl-7 pr-2 text-xs outline-none focus:border-orange-600"
              />
            </div>
            <button title="New file" onClick={() => createFile(false)} className="rounded p-1.5 hover:bg-zinc-800">
              <Plus className="h-3.5 w-3.5" />
            </button>
            <button title="New folder" onClick={() => createFile(true)} className="rounded p-1.5 hover:bg-zinc-800">
              <FolderPlus className="h-3.5 w-3.5" />
            </button>
          </div>
          <div className="flex-1 overflow-auto py-1">
            {tree.map((n) => (
              <TreeRow
                key={n.path}
                node={n}
                depth={0}
                openDirs={openDirs}
                toggleDir={(p) =>
                  setOpenDirs((prev) => {
                    const s = new Set(prev);
                    if (s.has(p)) s.delete(p);
                    else s.add(p);
                    return s;
                  })
                }
                activePath={activePath}
                onOpen={openFile}
                dirty={dirty}
              />
            ))}
          </div>
        </div>

        {/* Editor area */}
        <div className="flex min-w-0 flex-1 flex-col">
          {/* Tabs */}
          <div className="flex h-9 shrink-0 items-stretch overflow-x-auto border-b border-zinc-800 bg-zinc-900/30">
            {tabs.map((t) => (
              <div
                key={t.path}
                className={cn(
                  "group flex items-center gap-1.5 border-r border-zinc-800 px-3 text-sm",
                  activePath === t.path ? "bg-zinc-950 text-orange-400" : "text-zinc-400 hover:text-zinc-200"
                )}
              >
                <button onClick={() => setActivePath(t.path)} className="flex items-center gap-1.5">
                  {dirty.has(t.path) && <Circle className="h-2 w-2 fill-orange-400 text-orange-400" />}
                  {t.path.split("/").pop()}
                </button>
                <button onClick={() => closeTab(t.path)} className="opacity-0 group-hover:opacity-100">
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>

          {/* Monaco / empty state */}
          {activeTab ? (
            <div className="relative min-h-0 flex-1">
              <Editor
                key={activeTab.path}
                height="100%"
                theme="vs-dark"
                language={monacoLang}
                value={activeTab.content}
                onChange={(v) => updateContent(v ?? "")}
                options={{
                  fontSize: 13,
                  minimap: { enabled: false },
                  scrollBeyondLastLine: false,
                  padding: { top: 12 },
                  automaticLayout: true,
                }}
              />
              {/* context actions for active file */}
              <div className="absolute right-3 top-2 flex gap-1">
                <button
                  title="Rename"
                  onClick={() => renameFile(activeTab.path)}
                  className="rounded bg-zinc-900/80 p-1.5 text-zinc-400 hover:text-zinc-100"
                >
                  <PenLine className="h-3.5 w-3.5" />
                </button>
                <button
                  title="Delete"
                  onClick={() => deleteFile(activeTab.path)}
                  className="rounded bg-zinc-900/80 p-1.5 text-zinc-400 hover:text-red-400"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ) : (
            <div className="flex flex-1 items-center justify-center text-sm text-zinc-600">
              Select a file to start editing
            </div>
          )}
        </div>
      </div>

      {/* toast */}
      {toast && (
        <div className="pointer-events-none fixed bottom-6 left-1/2 -translate-x-1/2 rounded-lg border border-zinc-700 bg-zinc-900 px-4 py-2 text-sm shadow-xl">
          {toast}
        </div>
      )}

      {/* mobile hint */}
      <div className="border-t border-zinc-800 bg-zinc-900/60 px-3 py-1 text-center text-[10px] text-zinc-500 sm:hidden">
        Workspace is optimized for desktop
      </div>
    </div>
  );
}
