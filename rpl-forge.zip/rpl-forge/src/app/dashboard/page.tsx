"use client";

import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Plus, FolderGit2, Globe, Rocket, GitCommitHorizontal } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/primitives";
import { useAuth } from "@/components/auth-provider";
import { projectService } from "@/lib/services/project";
import type { Project } from "@/lib/types";
import { timeAgo } from "@/lib/utils";

export default function DashboardPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [projects, setProjects] = useState<Project[]>([]);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [user, loading, router]);

  useEffect(() => {
    if (user) setProjects(projectService.listByOwner(user.id));
  }, [user]);

  const stats = useMemo(() => {
    const live = projects.filter((p) => p.status === "LIVE").length;
    const deployments = projects.reduce(
      (acc, p) => acc + p.commits.length + (p.status === "LIVE" ? 0 : 1),
      0
    );
    const contributions = projects.reduce((acc, p) => acc + p.commits.length, 0);
    return { projects: projects.length, live, deployments, contributions };
  }, [projects]);

  if (loading || !user) return null;

  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

  const statCards = [
    { label: "Projects", value: stats.projects, icon: FolderGit2 },
    { label: "Live", value: stats.live, icon: Globe },
    { label: "Deployments", value: stats.deployments, icon: Rocket },
    { label: "Contributions", value: stats.contributions, icon: GitCommitHorizontal },
  ];

  return (
    <AppShell>
      <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">
            {greeting}, {user.name}.
          </h1>
          <p className="mt-1 text-sm text-zinc-400">Here&apos;s what&apos;s happening across your projects.</p>
        </div>
        <Button onClick={() => router.push("/projects/new")}>
          <Plus className="h-4 w-4" /> New Project
        </Button>
      </div>

      {/* Stats */}
      <div className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {statCards.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="rounded-lg border border-zinc-800 bg-zinc-900/40 p-4"
          >
            <div className="flex items-center justify-between">
              <span className="text-sm text-zinc-400">{s.label}</span>
              <s.icon className="h-4 w-4 text-zinc-500" />
            </div>
            <p className="mt-2 text-2xl font-semibold">{s.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Recent projects */}
      <div className="mt-8">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold">Recent projects</h2>
          <Link href="/projects" className="text-sm text-orange-500 hover:underline">
            View all
          </Link>
        </div>
        {projects.length === 0 ? (
          <div className="mt-4 rounded-lg border border-dashed border-zinc-800 p-10 text-center">
            <p className="text-zinc-400">No projects yet. Upload your first folder to go live.</p>
            <Button className="mt-4" onClick={() => router.push("/projects/new")}>
              <Plus className="h-4 w-4" /> New Project
            </Button>
          </div>
        ) : (
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {projects.slice(0, 6).map((p) => (
              <Link
                key={p.id}
                href={`/projects/${p.id}`}
                className="group rounded-lg border border-zinc-800 bg-zinc-900/40 p-4 transition-colors hover:border-zinc-700"
              >
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-medium group-hover:text-orange-500">{p.name}</h3>
                  <StatusBadge status={p.status} />
                </div>
                <p className="mt-1 line-clamp-2 text-sm text-zinc-400">{p.description}</p>
                <div className="mt-3 flex flex-wrap gap-1">
                  {p.technologies.slice(0, 3).map((t) => (
                    <Badge key={t} variant="outline">
                      {t}
                    </Badge>
                  ))}
                </div>
                <p className="mt-3 text-xs text-zinc-500">Updated {timeAgo(p.updatedAt)}</p>
              </Link>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}
