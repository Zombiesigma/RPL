"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Search, Anvil } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Badge, Input, Select } from "@/components/ui/primitives";
import { projectService } from "@/lib/services/project";
import { authService } from "@/lib/services/auth";
import { CATEGORIES, type Project } from "@/lib/types";

const TECHS = ["Next.js", "React", "Firebase", "Flutter", "Python", "TypeScript", "ESP32", "Tailwind", "Supabase", "Canvas", "Pandas", "Scikit-learn"];

export default function ExplorePage() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [tech, setTech] = useState("all");
  const [status, setStatus] = useState("all");
  const [year, setYear] = useState("all");

  useEffect(() => {
    setProjects(projectService.listPublic());
  }, []);

  const years = useMemo(() => {
    const set = new Set<string>();
    projects.forEach((p) => set.add(new Date(p.createdAt).getFullYear().toString()));
    return Array.from(set).sort().reverse();
  }, [projects]);

  const filtered = projects.filter((p) => {
    if (query && !(p.name + p.description).toLowerCase().includes(query.toLowerCase())) return false;
    if (category !== "all" && p.category !== category) return false;
    if (tech !== "all" && !p.technologies.includes(tech)) return false;
    if (status !== "all" && p.status !== status) return false;
    if (year !== "all" && new Date(p.createdAt).getFullYear().toString() !== year) return false;
    return true;
  });

  const ownerOf = (id: string) => authService.listDemoUsers().find((u) => u.id === id);

  return (
    <AppShell>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-bold tracking-tight">
            <Anvil className="h-6 w-6 text-orange-500" /> Explore
          </h1>
          <p className="mt-1 text-sm text-zinc-400">Discover what other students are forging.</p>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-zinc-500" />
          <Input
            placeholder="Search projects…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="border-zinc-800 bg-zinc-900 pl-8"
          />
        </div>
      </div>

      {/* Filters */}
      <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Select value={category} onChange={(e) => setCategory(e.target.value)} className="border-zinc-800 bg-zinc-900">
          <option value="all">All categories</option>
          {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
        </Select>
        <Select value={tech} onChange={(e) => setTech(e.target.value)} className="border-zinc-800 bg-zinc-900">
          <option value="all">All technologies</option>
          {TECHS.map((t) => <option key={t}>{t}</option>)}
        </Select>
        <Select value={status} onChange={(e) => setStatus(e.target.value)} className="border-zinc-800 bg-zinc-900">
          <option value="all">All statuses</option>
          <option value="LIVE">Live</option>
          <option value="DEPLOYING">Deploying</option>
          <option value="FAILED">Failed</option>
        </Select>
        <Select value={year} onChange={(e) => setYear(e.target.value)} className="border-zinc-800 bg-zinc-900">
          <option value="all">All years</option>
          {years.map((y) => <option key={y}>{y}</option>)}
        </Select>
      </div>

      {/* Grid */}
      {filtered.length === 0 ? (
        <div className="mt-8 rounded-lg border border-dashed border-zinc-800 p-12 text-center text-zinc-400">
          No projects match these filters.
        </div>
      ) : (
        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p) => {
            const owner = ownerOf(p.ownerId);
            return (
              <div key={p.id} className="flex flex-col rounded-lg border border-zinc-800 bg-zinc-900/40 p-4">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-medium">{p.name}</h3>
                  <StatusBadge status={p.status} />
                </div>
                <p className="mt-0.5 text-xs text-zinc-500">by @{owner?.username ?? "unknown"}</p>
                <p className="mt-2 line-clamp-2 flex-1 text-sm text-zinc-400">{p.description}</p>
                <div className="mt-3 flex flex-wrap gap-1">
                  {p.technologies.slice(0, 4).map((t) => (
                    <Badge key={t} variant="outline">{t}</Badge>
                  ))}
                </div>
                <Link href={`/projects/${p.id}`} className="mt-4">
                  <Button variant="outline" size="sm" className="w-full border-zinc-700">View Project</Button>
                </Link>
              </div>
            );
          })}
        </div>
      )}
    </AppShell>
  );
}
