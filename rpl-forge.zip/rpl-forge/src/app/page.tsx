"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { Anvil, ArrowRight, FolderUp, Globe, Code2, Rocket, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/components/auth-provider";

const STEPS = [
  { icon: FolderUp, title: "Upload", desc: "Choose your project folder. Structure kept intact." },
  { icon: Rocket, title: "Host", desc: "One click. Repository created, hosting prepared." },
  { icon: Globe, title: "Live", desc: "Your project gets a public URL in seconds." },
  { icon: Code2, title: "Continue", desc: "Edit code in the browser workspace and redeploy." },
];

export default function LandingPage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && user) router.replace("/dashboard");
  }, [user, loading, router]);

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <header className="border-b border-zinc-800/60">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <div className="flex items-center gap-2 font-semibold">
            <Anvil className="h-5 w-5 text-orange-500" />
            RPL Forge
          </div>
          <div className="flex items-center gap-2">
            <Link href="/explore" className="text-sm text-zinc-400 hover:text-zinc-100 px-3">
              Explore
            </Link>
            <Link href="/login">
              <Button size="sm">Sign in</Button>
            </Link>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-4 pt-20 pb-16 text-center">
        <div className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full border border-zinc-800 bg-zinc-900/60 px-3 py-1 text-xs text-zinc-400">
          <Sparkles className="h-3.5 w-3.5 text-orange-500" />
          Built for RPL students — no GitHub, no Vercel, no config
        </div>
        <h1 className="mx-auto max-w-3xl text-4xl font-bold tracking-tight sm:text-6xl">
          You have a project.
          <br />
          <span className="text-orange-500">Make it live.</span>
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-lg text-zinc-400">
          Upload a project folder, get a live URL instantly, keep building in the browser workspace.
          No infrastructure to learn — just ship.
        </p>
        <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Link href="/login">
            <Button size="lg" className="w-full sm:w-auto">
              Start forging <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
          <Link href="/explore">
            <Button size="lg" variant="outline" className="w-full border-zinc-700 sm:w-auto">
              Explore projects
            </Button>
          </Link>
        </div>

        <div className="mx-auto mt-16 grid max-w-4xl grid-cols-1 gap-3 sm:grid-cols-4">
          {STEPS.map((s, i) => (
            <div key={s.title} className="rounded-lg border border-zinc-800 bg-zinc-900/40 p-5 text-left">
              <span className="text-xs font-mono text-zinc-500">0{i + 1}</span>
              <s.icon className="mt-2 h-5 w-5 text-orange-500" />
              <h3 className="mt-2 font-semibold">{s.title}</h3>
              <p className="mt-1 text-sm text-zinc-400">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-t border-zinc-800/60 bg-zinc-900/30">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <pre className="mx-auto max-w-2xl overflow-x-auto rounded-lg border border-zinc-800 bg-zinc-950 p-6 text-left text-sm leading-relaxed text-zinc-300">
{`Project Folder          RPL Forge            The Internet
┌──────────────┐       ┌─────────────┐      ┌──────────────────┐
│ src/         │  ──▶  │  + Upload   │ ──▶  │ 🟢 project.live  │
│ package.json │       │  Auto-build │      │  edit & redeploy │
│ README.md    │       │  Auto-host  │      │  showcase it     │
└──────────────┘       └─────────────┘      └──────────────────┘`}
          </pre>
        </div>
      </section>

      <footer className="border-t border-zinc-800/60 py-8 text-center text-sm text-zinc-500">
        RPL Forge — a prototype platform for Rekayasa Perangkat Lunak students.
      </footer>
    </div>
  );
}
